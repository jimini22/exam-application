function nameCheck(){
	if (document.appForm.name.value.length==0) {
		alert("이름을 입력하세요");
		return;
	}
	
}

function ageCheck(){
	if (appForm.age.value.length==0) {
		alert("나이를 입력하세요");
		
	}
	
}


